﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DemoWeb.Data.Migrations
{
    public partial class Altercolumninemployeetable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "PhoneNumber",
                table: "Employees",
                newName: "MobileNumber");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "MobileNumber",
                table: "Employees",
                newName: "PhoneNumber");
        }
    }
}
