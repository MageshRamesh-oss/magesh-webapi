﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DemoWeb.Data.Migrations
{
    public partial class Altercolumninemployeetable1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
