﻿using DemoWeb.Data.Context;
using DemoWeb.Domain.Interfaces;
using DemoWeb.Domain.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoWeb.Data.Repository
{
    public class DepartmentRepository : IDepartmentRepository
    {
        private readonly DemoAPIDbContext _context;
        public DepartmentRepository(DemoAPIDbContext context)
        {
            _context = context;
        }

        public bool Add(Department obj)
        {
            using var transaction = _context.Database.BeginTransaction();
            try
            {
                _context.Departments.Add(obj);
                _context.SaveChanges();
                transaction.Commit();
                return true;
            }
            catch (Exception)
            {
                transaction.Rollback();
                return false;
            }
        }

        public Department Get(int id)
        {
           return _context.Departments.Find(id);
        }

        public IEnumerable<Department> GetAll()
        {
            return _context.Departments.ToList();
        }

        public bool Update(Department obj)
        {
            using var transaction = _context.Database.BeginTransaction();
            try
            {

                _context.Entry(obj).State = EntityState.Modified;
                _context.SaveChanges();
                transaction.Commit();

                return true;
            }
            catch (Exception)
            {
                transaction.Rollback();
                return false;
            }
        }
    }
}
