﻿using DemoWeb.Domain.Models;
using Microsoft.EntityFrameworkCore;

namespace DemoWeb.Data.Context
{
    public class DemoAPIDbContext:DbContext
    {
        public DemoAPIDbContext(DbContextOptions options):base(options)
        {

        }

        public virtual DbSet<Department> Departments { get; set; }
        public virtual DbSet<Employee> Employees { get; set; }

    }
}
