﻿using DemoWeb.Application.Interfaces;
using DemoWeb.Application.RequestModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DemoWeb.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentController : ControllerBase
    {
        private readonly IDepartmentService _context;
        public DepartmentController(IDepartmentService context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(_context.GetDepartments());
        }

        [HttpGet]
        [Route("GetById/{Id}")]
        public IActionResult GetbyId([FromRoute] int Id)
        {
            return Ok(_context.GetDepartment(Id));
        }

        [HttpPost]
        public IActionResult Post([FromBody]DepartmentRequest obj)
        {
            bool res = _context.AddDepartment(obj);
            if (res) { return Ok(); } else { return BadRequest(); }
        }

        [HttpPut]
        public IActionResult Put([FromBody] DepartmentRequest obj)
        {
            bool res = _context.UpdateDepartment(obj);
            if (res) { return Ok(); } else { return BadRequest(); }
        }
    }
}
