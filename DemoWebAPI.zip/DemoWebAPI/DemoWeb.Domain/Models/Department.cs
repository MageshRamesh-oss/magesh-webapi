﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoWeb.Domain.Models
{
    public class Department
    {
        [Key]
        public int Id { get; set; }
        [Required(AllowEmptyStrings = false)]
        public string Name { get; set; }
        [Required]
        public DateTime Created_At { get; set; }
        public DateTime Updated_At { get;set; }
        public bool IsDeleted { get; set; }
        
        
    }
}
