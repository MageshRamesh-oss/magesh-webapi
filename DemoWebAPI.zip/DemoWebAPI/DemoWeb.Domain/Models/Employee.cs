﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoWeb.Domain.Models
{
    public class Employee
    {
        [Key]
        public int Id { get; set; }
        [Required(AllowEmptyStrings = false)]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        [Required]
        public string MobileNumber { get; set; }
        [EmailAddress]
        [Required]
        public string EmailId { get; set; }
        [Required]
        public DateTime Created_At { get; set; }
        public DateTime Updated_At { get; set; }
        public bool IsDeleted { get; set; }

    }
}
