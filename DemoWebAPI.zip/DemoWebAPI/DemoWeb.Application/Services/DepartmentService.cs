﻿using DemoWeb.Application.Interfaces;
using DemoWeb.Application.RequestModel;
using DemoWeb.Domain.Interfaces;
using DemoWeb.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoWeb.Application.Services
{
    public class DepartmentService : IDepartmentService
    {
        private readonly IDepartmentRepository _context;
        public DepartmentService(IDepartmentRepository context)
        {
            _context = context;
        }

        public bool AddDepartment(DepartmentRequest obj)
        {
            var newDepartment = new Department
            {
                Name = obj.Name,
                Created_At = obj.Created_At,
                IsDeleted = false,

            };
            return _context.Add(newDepartment);
        }

        public object GetDepartment(int id)
        {
            return _context.Get(id);
        }

        public object GetDepartments()
        {
            return _context.GetAll();
        }

        public bool UpdateDepartment(DepartmentRequest obj)
        {
            var newDepartment = new Department
            {
                Id= obj.Id,
                Name = obj.Name,
                Created_At = obj.Created_At,
                IsDeleted = obj.IsDeleted,
                Updated_At=DateTime.Now

            };
            return _context.Update(newDepartment);
        }
    }
}
