﻿using DemoWeb.Application.Interfaces;

namespace DemoWeb.Application.Services
{
    public class TestService : ITestService
    {
        public string GetMethod()
        {
            return "Hello World !";

        }
    }
}
