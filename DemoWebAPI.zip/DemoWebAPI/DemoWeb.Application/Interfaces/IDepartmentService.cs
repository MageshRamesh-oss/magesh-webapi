﻿using DemoWeb.Application.RequestModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoWeb.Application.Interfaces
{
    public interface IDepartmentService
    {
        object GetDepartments();
        object GetDepartment(int id);
        bool AddDepartment(DepartmentRequest obj);
        bool UpdateDepartment(DepartmentRequest obj);
    }
}
