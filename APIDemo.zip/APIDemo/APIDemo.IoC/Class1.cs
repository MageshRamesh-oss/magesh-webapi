﻿using System;

namespace APIDemo.IoC
{
    public class Class1
    {
    }
}
