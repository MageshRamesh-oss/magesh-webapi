﻿using System;

namespace APIDemo.Domain
{
    public class Class1
    {
    }
}
